// Carne - 400 gr por pessoa + de 6 horas - 650 gr
// Cerveja - 1200 ml por pessoa + 6 horas - 2000 ml
// Refrigerante/Água - 1000 ml por pessoa + 6 horas 1500ml
// crianças valem por 0,5 -->



let inputAdultos = document.getElementById("adultos");
let inputCriancas = document.getElementById("criancas");
let inputDuracao = document.getElementById("duracao");
let meat;
let beer;
let drink;


function calculate () {
    adulto = inputAdultos.value;
    criancas = inputCriancas.value;
    duracao = inputDuracao.value;
    document.querySelector(".answer").style.display = "block";

    meat = (inputAdultos.value + (inputCriancas.value / 2)) * meatpp(duracao);

    beer = (inputAdultos.value) * beerpp(duracao);

    drink = (inputAdultos.value) * drinkpp(duracao);

    document.getElementsByName("meat")[0].innerHTML = "🍖 Total de Carne : " + meat/1000 + " Kg";

    document.getElementsByName("beer")[0].innerHTML = "🍺 Total de Bebida : " + Math.ceil(beer/1000) + " Litros";

    document.getElementsByName("drink")[0].innerHTML = "🍹 Total de Drinks :  " + Math.ceil(drink/1000) + " Litros";

    inputAdultos.value = "";
    inputCriancas.value = "";
    inputDuracao.value = "";
}

function meatpp (time){
    if(time >= 6){
        return 650;
    } else {
        return 400;
    }
}

function beerpp (time){
    if(time >= 6){
        return 2000;
    } else {
        return 1200;
    }
}

function drinkpp (time){
    if(time >= 6){
        return 1500;
    } else {
        return 1000;
    }
}

function hide () {
    document.querySelector(".answer").style.display = "none";
}